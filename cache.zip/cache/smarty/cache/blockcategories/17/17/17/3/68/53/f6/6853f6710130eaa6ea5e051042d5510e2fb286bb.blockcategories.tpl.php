<?php /*%%SmartyHeaderCode:19137398457bd898508b910-98485402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6853f6710130eaa6ea5e051042d5510e2fb286bb' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/blockcategories.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '3e89645364b658d2691a67d60666429c2056afa6' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19137398457bd898508b910-98485402',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57da5df7df37a4_44619388',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57da5df7df37a4_44619388')) {function content_57da5df7df37a4_44619388($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					EPOS Systems &amp; Hardware
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/receipt-printers-48" title="">
		Receipt Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/touch-screen-monitors-49" title="">
		Touch Screen Monitors
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/touch-screen-pos-50" title="">
		Touch Screen POS
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/customer-displays-51" title="">
		Customer Displays
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/cash-drawers-52" title="">
		Cash Drawers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/epos-software-53" title="">
		EPOS Software
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/magnetic-card-readers-54" title="">
		Magnetic Card Readers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/cheque-printers-55" title="">
		Cheque Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/in-counter-scanners-56" title="">
		In-Counter Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/kiosks-57" title="">
		Kiosks
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/digital-signage-58" title="">
		Digital Signage
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-59" title="">
		Accessories
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
