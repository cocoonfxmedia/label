<?php /*%%SmartyHeaderCode:19137398457bd898508b910-98485402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6853f6710130eaa6ea5e051042d5510e2fb286bb' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/blockcategories.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '3e89645364b658d2691a67d60666429c2056afa6' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19137398457bd898508b910-98485402',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84d6268c001_07263811',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84d6268c001_07263811')) {function content_57d84d6268c001_07263811($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Mobile Computers
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/rugged-pdas-38" title="">
		Rugged PDAs
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/handheld-computers-39" title="">
		Handheld Computers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/mobile-computers-40" title="">
		Mobile Computers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/rugged-tablets-pcs-41" title="">
		Rugged Tablets &amp; PCs
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/wearable-computers-42" title="">
		Wearable Computers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/vehicle-mounted-43" title="">
		Vehicle Mounted
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/portable-rfid-readers-44" title="">
		Portable RFID Readers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/portable-data-collectors-45" title="">
		Portable Data Collectors
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-46" title="">
		Accessories
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
