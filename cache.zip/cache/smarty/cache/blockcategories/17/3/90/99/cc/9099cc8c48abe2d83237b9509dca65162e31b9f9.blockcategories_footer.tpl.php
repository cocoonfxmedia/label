<?php /*%%SmartyHeaderCode:89904457757bd8986059ce6-97316646%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9099cc8c48abe2d83237b9509dca65162e31b9f9' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/blockcategories_footer.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '3e89645364b658d2691a67d60666429c2056afa6' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '89904457757bd8986059ce6-97316646',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a1a5ad1e1_83917504',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a1a5ad1e1_83917504')) {function content_57d84a1a5ad1e1_83917504($_smarty_tpl) {?>
<!-- Block categories module -->
<section class="blockcategories_footer footer-block col-xs-12 col-sm-2">
	<h4>Categories</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/epos-systems-hardware-17" title="Buy EPOS software, EPOS systems including receipt printers, EPOS touch screens, point of sale systems and magnetic stripe readers/encoders.">
		EPOS Systems &amp; Hardware
	</a>
			<ul>
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/receipt-printers-48" title="">
		Receipt Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/touch-screen-monitors-49" title="">
		Touch Screen Monitors
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/touch-screen-pos-50" title="">
		Touch Screen POS
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/customer-displays-51" title="">
		Customer Displays
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/cash-drawers-52" title="">
		Cash Drawers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/epos-software-53" title="">
		EPOS Software
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/magnetic-card-readers-54" title="">
		Magnetic Card Readers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/cheque-printers-55" title="">
		Cheque Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/in-counter-scanners-56" title="">
		In-Counter Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/kiosks-57" title="">
		Kiosks
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/digital-signage-58" title="">
		Digital Signage
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-59" title="">
		Accessories
	</a>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/scanners-3" title="Choose from the widest range of barcode scanners from manufacturers such as Motorola, Honeywell and Datalogic. You can find a barcode reader for every requirement. We stock many different types of barcode scanner and readers including 2D, laser, area, linear imager, handheld, wireless, bluetooth, rugged and fixed position barcode scanners.">
		Scanners
	</a>
			<ul>
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/handheld-scanners-19" title="">
		Handheld Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/wireless-scanners-20" title="">
		Wireless Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/bluetooth-barcode-scanners-21" title="">
		Bluetooth Barcode Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/omnidirectional-22" title="">
		Omnidirectional
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/2d-scanners-23" title="">
		2D Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/industrial-scanners-24" title="">
		Industrial Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/healthcare-scanners-25" title="">
		Healthcare Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/fixed-mount-scanners-26" title="">
		Fixed Mount Scanners
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/scanner-accessories-78" title="">
		Scanner Accessories
	</a>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/barcode-label-printers-15" title="Choose from a wide range of brands including Zebra, Intermec and Toshiba. We also sell the complete range of label printer accessories such as self adhesive labels, thermal transfer ribbons and thermal printheads.">
		Barcode Label Printers
	</a>
			<ul>
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/desktop-label-printers-27" title="">
		Desktop Label Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/mid-range-label-printers-28" title="">
		Mid Range Label Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/industrial-label-printers-29" title="">
		Industrial Label Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/high-performance-30" title="">
		High Performance
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/portable-label-printers-31" title="">
		Portable Label Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/colour-label-printers-32" title="">
		Colour Label Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/fixed-mount-printers-33" title="">
		Fixed Mount Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/print-engines-for-applicators-79" title="">
		Print Engines for Applicators
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/ticket-printers-34" title="">
		Ticket Printers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/kiosk-printers-35" title="">
		Kiosk Printers
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-47" title="">
		Accessories
	</a>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/mobile-computers-16" title="Choose from our extensive range of PDAs including rugged PDAs and models incorporating GPS, barcode scanners, cameras and more.">
		Mobile Computers
	</a>
			<ul>
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/rugged-pdas-38" title="">
		Rugged PDAs
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/handheld-computers-39" title="">
		Handheld Computers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/mobile-computers-40" title="">
		Mobile Computers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/rugged-tablets-pcs-41" title="">
		Rugged Tablets &amp; PCs
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/wearable-computers-42" title="">
		Wearable Computers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/vehicle-mounted-43" title="">
		Vehicle Mounted
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/portable-rfid-readers-44" title="">
		Portable RFID Readers
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/portable-data-collectors-45" title="">
		Portable Data Collectors
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-46" title="">
		Accessories
	</a>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/software-36" title="Buy labelling software and solutions including label design software from Industrial Printer Scan.">
		Software
	</a>
			<ul>
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/label-design-software-69" title="">
		Label Design Software
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/application-development-70" title="">
		Application Development
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/device-management-71" title="">
		Device Management
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/barcode-fonts-72" title="">
		Barcode Fonts
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/asset-tracking-73" title="">
		Asset Tracking
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/inventory-control-74" title="">
		Inventory Control
	</a>
	</li>

									</ul>
	</li>

							
																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/networking-37" title="Please call for expert advice on wireless networking solutions from Motorola Solutions or to arrange a RF site survey.">
		Networking
	</a>
			<ul>
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/access-points-75" title="">
		Access Points
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/switches-contollers-76" title="">
		Switches &amp; Contollers
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-77" title="">
		Accessories
	</a>
	</li>

									</ul>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
