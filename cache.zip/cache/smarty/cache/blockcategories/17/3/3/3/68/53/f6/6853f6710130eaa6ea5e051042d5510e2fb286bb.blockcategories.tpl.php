<?php /*%%SmartyHeaderCode:19137398457bd898508b910-98485402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6853f6710130eaa6ea5e051042d5510e2fb286bb' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/blockcategories.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '3e89645364b658d2691a67d60666429c2056afa6' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19137398457bd898508b910-98485402',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84d582ab9b6_74607441',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84d582ab9b6_74607441')) {function content_57d84d582ab9b6_74607441($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Scanners
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/handheld-scanners-19" title="">
		Handheld Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/wireless-scanners-20" title="">
		Wireless Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/bluetooth-barcode-scanners-21" title="">
		Bluetooth Barcode Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/omnidirectional-22" title="">
		Omnidirectional
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/2d-scanners-23" title="">
		2D Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/industrial-scanners-24" title="">
		Industrial Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/healthcare-scanners-25" title="">
		Healthcare Scanners
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/fixed-mount-scanners-26" title="">
		Fixed Mount Scanners
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/scanner-accessories-78" title="">
		Scanner Accessories
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
