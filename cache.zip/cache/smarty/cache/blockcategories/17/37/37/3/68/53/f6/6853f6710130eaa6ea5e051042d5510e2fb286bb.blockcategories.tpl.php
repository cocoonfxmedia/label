<?php /*%%SmartyHeaderCode:19137398457bd898508b910-98485402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6853f6710130eaa6ea5e051042d5510e2fb286bb' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/blockcategories.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '3e89645364b658d2691a67d60666429c2056afa6' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19137398457bd898508b910-98485402',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d9ab864c2b89_60366535',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d9ab864c2b89_60366535')) {function content_57d9ab864c2b89_60366535($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Networking
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/access-points-75" title="">
		Access Points
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/switches-contollers-76" title="">
		Switches &amp; Contollers
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/accessories-77" title="">
		Accessories
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
