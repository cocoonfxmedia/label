<?php /*%%SmartyHeaderCode:19137398457bd898508b910-98485402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6853f6710130eaa6ea5e051042d5510e2fb286bb' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/blockcategories.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '3e89645364b658d2691a67d60666429c2056afa6' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19137398457bd898508b910-98485402',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d9abca5273b0_01608306',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d9abca5273b0_01608306')) {function content_57d9abca5273b0_01608306($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Software
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://industrialprinterscan.co.uk/label-design-software-69" title="">
		Label Design Software
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/application-development-70" title="">
		Application Development
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/device-management-71" title="">
		Device Management
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/barcode-fonts-72" title="">
		Barcode Fonts
	</a>
	</li>

																
<li >
	<a 
	href="http://industrialprinterscan.co.uk/asset-tracking-73" title="">
		Asset Tracking
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://industrialprinterscan.co.uk/inventory-control-74" title="">
		Inventory Control
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
