<?php /*%%SmartyHeaderCode:195569728957be5d10ca2674-31604577%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a108bf1eaf86c0dca5b7eceb791af44d18a4e1ea' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockmanufacturer/blockmanufacturer.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '195569728957be5d10ca2674-31604577',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d8e719592cd6_10147167',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d8e719592cd6_10147167')) {function content_57d8e719592cd6_10147167($_smarty_tpl) {?>
<!-- Block manufacturers module -->
<div id="manufacturers_block_left" class="block blockmanufacturer">
	<p class="title_block">
					<a href="http://industrialprinterscan.co.uk/manufacturers" title="Manufacturers">
						Manufacturers
					</a>
			</p>
	<div class="block_content list-block">
								<ul>
														<li class="first_item">
						<a 
						href="http://industrialprinterscan.co.uk/47_24v" title="More about 24V">
							24V
						</a>
					</li>
																			<li class="item">
						<a 
						href="http://industrialprinterscan.co.uk/18_4k" title="More about 4K">
							4K
						</a>
					</li>
																			<li class="item">
						<a 
						href="http://industrialprinterscan.co.uk/20_acr-sas" title="More about ACR SAS">
							ACR SAS
						</a>
					</li>
																			<li class="item">
						<a 
						href="http://industrialprinterscan.co.uk/44_advantech-dlog" title="More about Advantech-DLoG">
							Advantech-DLoG
						</a>
					</li>
																			<li class="item">
						<a 
						href="http://industrialprinterscan.co.uk/4_apg-cash-drawer" title="More about APG CASH DRAWER">
							APG CASH DRAWER
						</a>
					</li>
																																																																																																																																																																																																																																																																																																																																																																																																																																																												</ul>
										<form action="/index.php" method="get">
					<div class="form-group selector1">
						<select class="form-control" name="manufacturer_list">
							<option value="0">All manufacturers</option>
													<option value="http://industrialprinterscan.co.uk/47_24v">24V</option>
													<option value="http://industrialprinterscan.co.uk/18_4k">4K</option>
													<option value="http://industrialprinterscan.co.uk/20_acr-sas">ACR SAS</option>
													<option value="http://industrialprinterscan.co.uk/44_advantech-dlog">Advantech-DLoG</option>
													<option value="http://industrialprinterscan.co.uk/4_apg-cash-drawer">APG CASH DRAWER</option>
													<option value="http://industrialprinterscan.co.uk/5_bartec">BARTEC</option>
													<option value="http://industrialprinterscan.co.uk/6_batstar">BATSTAR</option>
													<option value="http://industrialprinterscan.co.uk/2_brother">Brother</option>
													<option value="http://industrialprinterscan.co.uk/7_cables-direct">Cables Direct</option>
													<option value="http://industrialprinterscan.co.uk/8_code">CODE</option>
													<option value="http://industrialprinterscan.co.uk/10_datalogic">DATALOGIC</option>
													<option value="http://industrialprinterscan.co.uk/9_datamax-oneil">DATAMAX-ONEIL</option>
													<option value="http://industrialprinterscan.co.uk/16_datema">DATEMA</option>
													<option value="http://industrialprinterscan.co.uk/40_dosmar">Dosmar</option>
													<option value="http://industrialprinterscan.co.uk/3_elo">elo</option>
													<option value="http://industrialprinterscan.co.uk/12_elo-touch-solutions">ELO Touch Solutions</option>
													<option value="http://industrialprinterscan.co.uk/48_empowered">EMPOWERED</option>
													<option value="http://industrialprinterscan.co.uk/17_epson">EPSON</option>
													<option value="http://industrialprinterscan.co.uk/13_ergonomic-solutions">Ergonomic Solutions</option>
													<option value="http://industrialprinterscan.co.uk/11_european-cash-drawers">EUROPEAN CASH DRAWERS</option>
													<option value="http://industrialprinterscan.co.uk/49_europlus-direct">Europlus Direct</option>
													<option value="http://industrialprinterscan.co.uk/19_global-technology-systems">Global Technology Systems</option>
													<option value="http://industrialprinterscan.co.uk/14_honeywell-scanning-mobi">Honeywell Scanning &amp; Mobi</option>
													<option value="http://industrialprinterscan.co.uk/15_ibm">IBM</option>
													<option value="http://industrialprinterscan.co.uk/28_intercompany">Intercompany</option>
													<option value="http://industrialprinterscan.co.uk/42_m3mobile">M3Mobile</option>
													<option value="http://industrialprinterscan.co.uk/22_mcl">MCL</option>
													<option value="http://industrialprinterscan.co.uk/53_mmf">MMF</option>
													<option value="http://industrialprinterscan.co.uk/30_mobilis">Mobilis</option>
													<option value="http://industrialprinterscan.co.uk/33_motion-computing">MOTION COMPUTING</option>
													<option value="http://industrialprinterscan.co.uk/38_nemesis">Nemesis</option>
													<option value="http://industrialprinterscan.co.uk/43_one-time-vendor">One Time Vendor</option>
													<option value="http://industrialprinterscan.co.uk/24_pioneerpos">PioneerPOS</option>
													<option value="http://industrialprinterscan.co.uk/31_portsmith">Portsmith</option>
													<option value="http://industrialprinterscan.co.uk/26_printronix">Printronix</option>
													<option value="http://industrialprinterscan.co.uk/52_q-com">Q Com</option>
													<option value="http://industrialprinterscan.co.uk/35_ruckus">Ruckus</option>
													<option value="http://industrialprinterscan.co.uk/41_sato">Sato</option>
													<option value="http://industrialprinterscan.co.uk/51_scansource">SCANSOURCE</option>
													<option value="http://industrialprinterscan.co.uk/50_seagull">Seagull</option>
													<option value="http://industrialprinterscan.co.uk/21_sensorecs">SENSORECS</option>
													<option value="http://industrialprinterscan.co.uk/34_socket-mobile">Socket Mobile</option>
													<option value="http://industrialprinterscan.co.uk/25_tailored-card-services">Tailored Card Services</option>
													<option value="http://industrialprinterscan.co.uk/46_tc-installations">TC Installations</option>
													<option value="http://industrialprinterscan.co.uk/37_technology-solutions">Technology Solutions</option>
													<option value="http://industrialprinterscan.co.uk/32_tis-gmbh">TIS GMBH</option>
													<option value="http://industrialprinterscan.co.uk/45_toshiba">Toshiba</option>
													<option value="http://industrialprinterscan.co.uk/36_toughshield">TOUGHSHIELD</option>
													<option value="http://industrialprinterscan.co.uk/39_unitech">Unitech</option>
													<option value="http://industrialprinterscan.co.uk/27_wincor-nixdorf">Wincor-Nixdorf</option>
													<option value="http://industrialprinterscan.co.uk/23_zebra">Zebra</option>
													<option value="http://industrialprinterscan.co.uk/29_zebra-card">Zebra Card</option>
													<option value="http://industrialprinterscan.co.uk/1_zebra-technologies">Zebra Technologies</option>
												</select>
					</div>
				</form>
						</div>
</div>
<!-- /Block manufacturers module -->
<?php }} ?>
