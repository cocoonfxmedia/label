<?php /*%%SmartyHeaderCode:157036837057bd8985d568e1-26347766%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a9ebe99a26ec0c346160ab86343b8458782f286' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blocksocial/blocksocial.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '157036837057bd8985d568e1-26347766',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a1a410d66_09779599',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a1a410d66_09779599')) {function content_57d84a1a410d66_09779599($_smarty_tpl) {?><section id="social_block" class="pull-right">
	<ul>
					<li class="facebook">
				<a class="_blank" href="https://www.facebook.com/industrialprinterscan/">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a class="_blank" href="#">
					<span>Twitter</span>
				</a>
			</li>
				                	<li class="youtube">
        		<a class="_blank" href="#">
        			<span>Youtube</span>
        		</a>
        	</li>
                        	<li class="google-plus">
        		<a class="_blank" href="#" rel="publisher">
        			<span>Google Plus</span>
        		</a>
        	</li>
                                	</ul>
    <h4>Follow us</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>
