<?php /*%%SmartyHeaderCode:116484255357bd89856bd701-80958286%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2dca41b68038875cd5aee93a634fa480d23bb10' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blocknewproducts/blocknewproducts.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '116484255357bd89856bd701-80958286',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84d5853fc08_81087462',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84d5853fc08_81087462')) {function content_57d84d5853fc08_81087462($_smarty_tpl) {?><!-- MODULE Block new products -->
<div id="new-products_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://industrialprinterscan.co.uk/new-products" title="New products">New products</a>
    </h4>
    <div class="block_content products-block">
                    <ul class="products">
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" title="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2984-small_default/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50.jpg" alt="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" title="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)">BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)</a>
                            </h5>
                        	<p class="product-description">Mfr Part #: BTRY-MC7XEAB00-50</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 1,168.64                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" title="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2983-small_default/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl.jpg" alt="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" title="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)">SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)</a>
                            </h5>
                        	<p class="product-description">SKU: HA00617160Brand: ZebraMfr Part #: SAC7X00-401CES</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 119.69                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" title="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2982-small_default/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10.jpg" alt="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" title="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)">BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)</a>
                            </h5>
                        	<p class="product-description">SKU: HA00615000Brand: ZebraMfr Part #: BTRY-MC95IABA0-10</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 414.44                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" title="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2981-small_default/btry-kt-1x-es40-motorola-es400-standard-battery-kit.jpg" alt="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" title="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit">BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit</a>
                            </h5>
                        	<p class="product-description">SKU: HA00616293Brand: ZebraMfr Part #: BTRY-KT-1X-ES40</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 23.05                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" title="Intermec 318-039-012 Battery Pack"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2980-small_default/intermec-318-039-012-battery-pack.jpg" alt="Intermec 318-039-012 Battery Pack" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" title="Intermec 318-039-012 Battery Pack">Intermec 318-039-012 Battery Pack</a>
                            </h5>
                        	<p class="product-description">Brand: IntermecMfr Part #: 318-039-012</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 61.30                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" title="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2979-small_default/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black.jpg" alt="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" title="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black">BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black</a>
                            </h5>
                        	<p class="product-description">Brand: HoneywellMfr Part #: BAT-STANDARD-01</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 33.35                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" title="BTRY-MC55EAB00 Motorola MC55 Standard Battery"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2978-small_default/btry-mc55eab00-motorola-mc55-standard-battery.jpg" alt="BTRY-MC55EAB00 Motorola MC55 Standard Battery" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" title="BTRY-MC55EAB00 Motorola MC55 Standard Battery">BTRY-MC55EAB00 Motorola MC55 Standard Battery</a>
                            </h5>
                        	<p class="product-description">SKU: HA00613708Brand: ZebraMfr Part #: BTRY-MC55EAB00</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 25.36                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" title="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery"><img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2977-small_default/6000-btsc-honeywell-dolphin-6x00-standard-battery.jpg" alt="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" title="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery">6000-BTSC - Honeywell Dolphin 6X00 Standard Battery</a>
                            </h5>
                        	<p class="product-description">SKU: HE00621716Mfr Part #: 6000-BTSC</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	£ 36.83                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                            </ul>
            <div>
                <a href="http://industrialprinterscan.co.uk/new-products" title="All new products" class="btn btn-default button button-small"><span>All new products<i class="icon-chevron-right right"></i></span></a>
            </div>
            </div>
</div>
<!-- /MODULE Block new products --><?php }} ?>
