<?php /*%%SmartyHeaderCode:209469626557bd89852e1f81-01285628%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '21d0e9d1e428ebd14349a1f65a9a4419a8afdcb5' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcms/blockcms.tpl',
      1 => 1465940665,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '209469626557bd89852e1f81-01285628',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a1a693ce6_64307027',
  'has_nocache_code' => true,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a1a693ce6_64307027')) {function content_57d84a1a693ce6_64307027($_smarty_tpl) {?>
	<!-- Block CMS module footer -->
	<section class="footer-block col-xs-12 col-sm-2" id="block_various_links_footer">
		<h4>Information</h4>
		<ul class="toggle-footer">
							<li class="item">
					<a href="http://industrialprinterscan.co.uk/prices-drop" title="Specials">
						Specials
					</a>
				</li>
									<li class="item">
				<a href="http://industrialprinterscan.co.uk/new-products" title="New products">
					New products
				</a>
			</li>
										<li class="item">
					<a href="http://industrialprinterscan.co.uk/best-sales" title="Best sellers">
						Best sellers
					</a>
				</li>
										<li class="item">
					<a href="http://industrialprinterscan.co.uk/stores" title="Our stores">
						Our stores
					</a>
				</li>
									<li class="item">
				<a href="http://industrialprinterscan.co.uk/contact-us" title="Contact us">
					Contact us
				</a>
			</li>
																										<li>
				<a href="http://industrialprinterscan.co.uk/sitemap" title="Sitemap">
					Sitemap
				</a>
			</li>
					</ul>
		
	</section>
		<section class="bottom-footer col-xs-12">
		<div>
			<?php echo smartyTranslate(array('s'=>'[1] %3$s %2$s - Hosted and Setup by %1$s [/1]','mod'=>'blockcms','sprintf'=>array('BitzUK',date('Y'),'&copy;'),'tags'=>array('<a class="_blank" href="http://www.bitzuk.com">')),$_smarty_tpl);?>

		</div>
	</section>
		<!-- /Block CMS module footer -->
<?php }} ?>
