<?php /*%%SmartyHeaderCode:209469626557bd89852e1f81-01285628%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '21d0e9d1e428ebd14349a1f65a9a4419a8afdcb5' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcms/blockcms.tpl',
      1 => 1465940665,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '209469626557bd89852e1f81-01285628',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84d583f5c31_74289134',
  'has_nocache_code' => true,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84d583f5c31_74289134')) {function content_57d84d583f5c31_74289134($_smarty_tpl) {?>
	<!-- Block CMS module -->
			<section id="informations_block_left_1" class="block informations_block_left">
			<p class="title_block">
				<a href="http://industrialprinterscan.co.uk/content/category/1-home">
					Information				</a>
			</p>
			<div class="block_content list-block">
				<ul>
																							<li>
								<a href="http://industrialprinterscan.co.uk/content/1-delivery" title="Delivery">
									Delivery
								</a>
							</li>
																						<li>
							<a href="http://industrialprinterscan.co.uk/stores" title="Our stores">
								Our stores
							</a>
						</li>
									</ul>
			</div>
		</section>
		<!-- /Block CMS module -->
<?php }} ?>
