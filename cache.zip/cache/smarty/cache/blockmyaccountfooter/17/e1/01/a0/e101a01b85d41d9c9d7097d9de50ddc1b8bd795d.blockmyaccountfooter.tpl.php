<?php /*%%SmartyHeaderCode:92365427857bd8986273ce7-27460370%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e101a01b85d41d9c9d7097d9de50ddc1b8bd795d' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockmyaccountfooter/blockmyaccountfooter.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '92365427857bd8986273ce7-27460370',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a26ade718_39569855',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a26ade718_39569855')) {function content_57d84a26ade718_39569855($_smarty_tpl) {?>
<!-- Block myaccount module -->
<section class="footer-block col-xs-12 col-sm-4">
	<h4><a href="http://industrialprinterscan.co.uk/my-account" title="Manage my customer account" rel="nofollow">My account</a></h4>
	<div class="block_content toggle-footer">
		<ul class="bullet">
			<li><a href="http://industrialprinterscan.co.uk/order-history" title="My orders" rel="nofollow">My orders</a></li>
						<li><a href="http://industrialprinterscan.co.uk/credit-slip" title="My credit slips" rel="nofollow">My credit slips</a></li>
			<li><a href="http://industrialprinterscan.co.uk/addresses" title="My addresses" rel="nofollow">My addresses</a></li>
			<li><a href="http://industrialprinterscan.co.uk/identity" title="Manage my personal information" rel="nofollow">My personal info</a></li>
						
            		</ul>
	</div>
</section>
<!-- /Block myaccount module -->
<?php }} ?>
