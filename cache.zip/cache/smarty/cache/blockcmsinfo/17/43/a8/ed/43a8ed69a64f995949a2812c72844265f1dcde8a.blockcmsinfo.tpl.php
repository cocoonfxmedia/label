<?php /*%%SmartyHeaderCode:163092326357bda1323d1542-43037286%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '43a8ed69a64f995949a2812c72844265f1dcde8a' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/modules/blockcmsinfo/blockcmsinfo.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '163092326357bda1323d1542-43037286',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a1cec09e3_72308303',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a1cec09e3_72308303')) {function content_57d84a1cec09e3_72308303($_smarty_tpl) {?><!-- MODULE Block cmsinfo -->
<div id="cmsinfo_block">
					<div class="col-xs-6"><ul><li><em class="icon-truck" id="icon-truck"></em>
<div class="type-text">
<h3>Delivery</h3>
<p>Your package will be shipped within 5 working days providing the item is in stock. For bulk orders; please contact for an exact delivery price.</p>
</div>
</li>
<li><em class="icon-phone" id="icon-phone"></em>
<div class="type-text">
<h3>Get in Touch</h3>
<p>Please contact us with any questions. Lines are open during standard working hours.</p>
</div>
</li>
<li><em class="icon-credit-card" id="icon-credit-card"></em>
<div class="type-text">
<h3>Payment</h3>
<p>All major forms of credit and debit card are accepted.</p>
</div>
</li>
</ul></div>
					<div class="col-xs-6"><h3>About Us</h3>
<p><strong>Industrial Printer Scan LTD</strong></p>
<p><span>Is an independently owned electronic supply and repair company based in the midlands. Over the years we have established ourself as a leading supplier of cutting edge, ready to go digital equipment to a wide cross section of business and commercial sectors in the Midlands and across the UK. Stand alone or integrated systems, with such a wide selection of choice we can offer our customers a service at competitive rates for electronic point of sale equipment.</span></p></div>
		</div>
<!-- /MODULE Block cmsinfo -->
<?php }} ?>
