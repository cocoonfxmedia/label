<?php /*%%SmartyHeaderCode:27560928657bd8987ac8cc6-96120885%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '13aecab5403a76e89fee27bbe9f70a9f1db7b84a' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcontact/nav.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27560928657bd8987ac8cc6-96120885',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a1a91a541_05783872',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a1a91a541_05783872')) {function content_57d84a1a91a541_05783872($_smarty_tpl) {?><div id="contact-link" >
	<a href="http://industrialprinterscan.co.uk/contact-us" title="Contact us">Contact us</a>
</div>
	<span class="shop-phone">
		<i class="icon-phone"></i>Call us now: <strong>01827 767910</strong>
	</span>
<?php }} ?>
