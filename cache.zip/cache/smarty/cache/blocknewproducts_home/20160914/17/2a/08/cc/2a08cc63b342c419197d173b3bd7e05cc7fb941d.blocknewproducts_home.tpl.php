<?php /*%%SmartyHeaderCode:183886008657bda132844ac0-13562624%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2a08cc63b342c419197d173b3bd7e05cc7fb941d' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/modules/blocknewproducts/views/templates/hook/blocknewproducts_home.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
    '814279ecdd47c230352e3f7e3ace4ead427f44f1' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/product-list.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '183886008657bda132844ac0-13562624',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d8a8c9020918_34724733',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d8a8c9020918_34724733')) {function content_57d8a8c9020918_34724733($_smarty_tpl) {?>		
									
		
	
	<!-- Products list -->
	<ul id="blocknewproducts" class="product_list grid row blocknewproducts tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line first-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" title="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2984-home_default/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50.jpg" alt="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)" title="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" rel="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" rel="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 1,168.64									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" title="BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A 3600 mAh (Pack of 50)" itemprop="url" >
							BTRY-MC7XEAB00-50 Motorola MC70/MC75/MC75A...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Mfr Part #: BTRY-MC7XEAB00-50
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 1,168.64							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3808&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3808" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/btry-mc7xeab00-50-motorola-mc70mc75mc75a-3600-mah-pack-of-50-3808.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" title="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2983-home_default/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl.jpg" alt="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)" title="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" rel="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" rel="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 119.69									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" title="SAC7X00-401CES Motorola 4-Slot Battery Charger Kit (INTL)" itemprop="url" >
							SAC7X00-401CES Motorola 4-Slot Battery...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						SKU: HA00617160Brand: ZebraMfr Part #: SAC7X00-401CES
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 119.69							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3807&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3807" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/sac7x00-401ces-motorola-4-slot-battery-charger-kit-intl-3807.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" title="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2982-home_default/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10.jpg" alt="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)" title="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" rel="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" rel="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 414.44									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" title="BTRY-MC95IABA0-10 - Motorola MC9500 Intelligent Battery (Pack of 10)" itemprop="url" >
							BTRY-MC95IABA0-10 - Motorola MC9500...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						SKU: HA00615000Brand: ZebraMfr Part #: BTRY-MC95IABA0-10
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 414.44							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3806&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3806" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/btry-mc95iaba0-10-motorola-mc9500-intelligent-battery-pack-of-10-3806.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-in-line first-item-of-tablet-line last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" title="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2981-home_default/btry-kt-1x-es40-motorola-es400-standard-battery-kit.jpg" alt="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit" title="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" rel="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" rel="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 23.05									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" title="BTRY-KT-1X-ES40 - Motorola ES400 Standard Battery Kit" itemprop="url" >
							BTRY-KT-1X-ES40 - Motorola ES400 Standard...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						SKU: HA00616293Brand: ZebraMfr Part #: BTRY-KT-1X-ES40
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 23.05							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3805&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3805" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/btry-kt-1x-es40-motorola-es400-standard-battery-kit-3805.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" title="Intermec 318-039-012 Battery Pack" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2980-home_default/intermec-318-039-012-battery-pack.jpg" alt="Intermec 318-039-012 Battery Pack" title="Intermec 318-039-012 Battery Pack"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" rel="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" rel="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 61.30									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" title="Intermec 318-039-012 Battery Pack" itemprop="url" >
							Intermec 318-039-012 Battery Pack
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Brand: IntermecMfr Part #: 318-039-012
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 61.30							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3804&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3804" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/intermec-318-039-012-battery-pack-3804.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-tablet-line last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" title="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2979-home_default/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black.jpg" alt="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black" title="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" rel="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" rel="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 33.35									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" title="BAT-STANDARD-01 - Honeywell Standard Battery Pack for Dolphin 70e Black" itemprop="url" >
							BAT-STANDARD-01 - Honeywell Standard...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Brand: HoneywellMfr Part #: BAT-STANDARD-01
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 33.35							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3803&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3803" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/bat-standard-01-honeywell-standard-battery-pack-for-dolphin-70e-black-3803.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line first-item-of-tablet-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" title="BTRY-MC55EAB00 Motorola MC55 Standard Battery" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2978-home_default/btry-mc55eab00-motorola-mc55-standard-battery.jpg" alt="BTRY-MC55EAB00 Motorola MC55 Standard Battery" title="BTRY-MC55EAB00 Motorola MC55 Standard Battery"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" rel="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" rel="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 25.36									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" title="BTRY-MC55EAB00 Motorola MC55 Standard Battery" itemprop="url" >
							BTRY-MC55EAB00 Motorola MC55 Standard Battery
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						SKU: HA00613708Brand: ZebraMfr Part #: BTRY-MC55EAB00
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 25.36							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3802&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3802" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/btry-mc55eab00-motorola-mc55-standard-battery-3802.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-in-line last-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" title="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery" itemprop="url">
							<img class="replace-2x img-responsive" src="http://industrialprinterscan.co.uk/2977-home_default/6000-btsc-honeywell-dolphin-6x00-standard-battery.jpg" alt="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery" title="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" rel="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" rel="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										£ 36.83									</span>
									<meta itemprop="priceCurrency" content="GBP" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" title="6000-BTSC - Honeywell Dolphin 6X00 Standard Battery" itemprop="url" >
							6000-BTSC - Honeywell Dolphin 6X00...
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						SKU: HE00621716Mfr Part #: 6000-BTSC
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								£ 36.83							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://industrialprinterscan.co.uk/cart?add=1&amp;id_product=3801&amp;token=5f27c9511a900c89274d97d9ffc7935e" rel="nofollow" title="Add to cart" data-id-product-attribute="0" data-id-product="3801" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://industrialprinterscan.co.uk/home/6000-btsc-honeywell-dolphin-6x00-standard-battery-3801.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-warning">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
