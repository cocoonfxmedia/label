<?php /*%%SmartyHeaderCode:15644618557bd898637fda9-01216496%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce0f65a789b5a5d5b7abf05692fa6cff590b486b' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blockcontactinfos/blockcontactinfos.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15644618557bd898637fda9-01216496',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84a1a76aad6_34275007',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84a1a76aad6_34275007')) {function content_57d84a1a76aad6_34275007($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
	<div>
        <h4>Store Information</h4>
        <ul class="toggle-footer">
                        	<li>
            		<i class="icon-map-marker"></i>Industrial Printer Scan LTD, 4 Little Church Lane, Staffordshire, B79 7AX            	</li>
                                    	<li>
            		<i class="icon-phone"></i>Call us now: 
            		<span>01827 767910</span>
            	</li>
                                    	<li>
            		<i class="icon-envelope-alt"></i>Email: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%65%6e%71%75%69%72%69%65%73@%69%6e%64%75%73%74%72%69%61%6c%70%72%69%6e%74%65%72%73%63%61%6e.%63%6f.%75%6b" >&#x65;&#x6e;&#x71;&#x75;&#x69;&#x72;&#x69;&#x65;&#x73;&#x40;&#x69;&#x6e;&#x64;&#x75;&#x73;&#x74;&#x72;&#x69;&#x61;&#x6c;&#x70;&#x72;&#x69;&#x6e;&#x74;&#x65;&#x72;&#x73;&#x63;&#x61;&#x6e;&#x2e;&#x63;&#x6f;&#x2e;&#x75;&#x6b;</a></span>
            	</li>
                    </ul>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
