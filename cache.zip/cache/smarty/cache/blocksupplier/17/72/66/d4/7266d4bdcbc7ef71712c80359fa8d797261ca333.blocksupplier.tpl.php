<?php /*%%SmartyHeaderCode:203898381157be5d1169b171-18532491%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7266d4bdcbc7ef71712c80359fa8d797261ca333' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/themes/default-bootstrap/modules/blocksupplier/blocksupplier.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203898381157be5d1169b171-18532491',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d8e719714a91_09927816',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d8e719714a91_09927816')) {function content_57d8e719714a91_09927816($_smarty_tpl) {?>
<!-- Block suppliers module -->
<div id="suppliers_block_left" class="block blocksupplier">
	<p class="title_block">
					<a href="http://industrialprinterscan.co.uk/supplier" title="Suppliers">
					Suppliers
					</a>
			</p>
	<div class="block_content list-block">
								<ul>
											<li class="last_item">
                					<a 
					href="http://industrialprinterscan.co.uk/1__fashion-supplier" 
					title="More about Fashion Supplier">
				                Fashion Supplier
                					</a>
                				</li>
										</ul>
										<form action="/index.php" method="get">
					<div class="form-group selector1">
						<select class="form-control" name="supplier_list">
							<option value="0">All suppliers</option>
													<option value="http://industrialprinterscan.co.uk/1__fashion-supplier">Fashion Supplier</option>
												</select>
					</div>
				</form>
						</div>
</div>
<!-- /Block suppliers module -->
<?php }} ?>
