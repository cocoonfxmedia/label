<?php /*%%SmartyHeaderCode:42362490057bda132555ed5-85211844%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e2c26b910fe7a77935c7844bf841dafd4a1d3a34' => 
    array (
      0 => '/home/sites/industrialprinterscan.co.uk/public_html/modules/blocknewproducts/views/templates/hook/tab.tpl',
      1 => 1448896648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '42362490057bda132555ed5-85211844',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d9faf79fd595_04751489',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d9faf79fd595_04751489')) {function content_57d9faf79fd595_04751489($_smarty_tpl) {?><li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">New arrivals</a></li>
<?php }} ?>
